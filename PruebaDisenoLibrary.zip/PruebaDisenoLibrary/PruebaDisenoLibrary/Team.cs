﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PruebaDisenoLibrary
{
    public class Team
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string City { get; set; }

        public int FoundationalYear { get; set; }

        public List<Player> Players { get; set; }

        public Team(string nName, string nCity, int nFoundationalYear)
        {
            Name = nName;
            City = nCity;
            FoundationalYear = nFoundationalYear;
            Players = new List<Player>();

        }

    }
}
