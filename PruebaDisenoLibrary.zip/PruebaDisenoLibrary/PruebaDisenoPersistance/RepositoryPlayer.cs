﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PruebaDisenoLibrary;
using System.Data.Entity;

namespace PruebaDisenoPersistance
{
    public class RepositoryPlayer : IRepository<Player>
    {
        public RepositoryPlayer()
        {

        }


        public virtual List<Player> GetAll()
        {
            using (var context = new Context())
            {
                return context.Players.ToList();
            }
        }


        public virtual Player Get(int id)
        {
        
         using (var context = new Context())
         {
            return context.Players.Find(id);

         }
            
           
        }
        public virtual void Insert(Player p)
        {
            using (var context = new Context())
            {
                context.Players.Add(p);
                context.SaveChanges();

            }
            

        }
        public virtual void Remove(Player p)
        {
            
            using (var context = new Context())
            {
                var player = context.Players.Find(p.Id);
                context.Players.Remove(p);
                context.SaveChanges();
            }
            
        }

        public virtual void Update(Player o, Player n)
        {

                using (var context = new Context())
                {
                    var old = context.Players.Find(o.Id);
                    old.SkillLevel = n.SkillLevel;
                    context.Entry(old).State = EntityState.Modified;
                    context.SaveChanges();
                }


        }


    }
}
