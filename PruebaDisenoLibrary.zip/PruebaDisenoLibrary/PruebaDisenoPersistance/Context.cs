﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PruebaDisenoLibrary;
using System.Data.Entity;

namespace PruebaDisenoPersistance
{
    public class Context : DbContext
    {
        public DbSet<Player> Players { get; set; }
        public DbSet<Team> Teams { get; set; }

        public Context() : base("defaultConnection")
        {
            Database.SetInitializer(new DropCreateDatabaseIfModelChanges<Context>());
        }

        public object CreateObjectSet<T>()
        {
            throw new NotImplementedException();
        }
    }
}
