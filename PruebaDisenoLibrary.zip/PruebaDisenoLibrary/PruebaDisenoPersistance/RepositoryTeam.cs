﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PruebaDisenoLibrary;
using System.Data.Entity;

namespace PruebaDisenoPersistance
{
    public class RepositoryTeam : IRepository<Team>
    {
        public RepositoryTeam()
        {

        }


        public virtual List<Team> GetAll()
        {
            using (var context = new Context())
            {
                return context.Teams.ToList();
            }
        }

        public virtual Team Get(int id)
        {

            using (var context = new Context())
            {
                return context.Teams.Find(id);

            }


        }
        public virtual void Insert(Team t)
        {
            using (var context = new Context())
            {
                context.Teams.Add(t);
                context.SaveChanges();

            }


        }
        public virtual void Remove(Team t)
        {
        
            using (var context = new Context())
            {
                var team = context.Teams.Find(t.Id);
                context.Teams.Remove(t);
                context.SaveChanges();
            }

        }

        public virtual void Update(Team o, Team n)
        {

            using (var context = new Context())
            {
                var old = context.Teams.Find(o.Id);
                old.City = n.City;
                old.FoundationalYear = n.FoundationalYear;
                old.Players = n.Players;
                context.Entry(old).State = EntityState.Modified;
                context.SaveChanges();
            }


        }



    }
}
