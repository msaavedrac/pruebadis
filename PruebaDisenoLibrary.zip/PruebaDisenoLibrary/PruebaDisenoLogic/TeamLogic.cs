﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PruebaDisenoPersistance;
using PruebaDisenoLibrary;

namespace PruebaDisenoLogic
{
    public class TeamLogic
    {
        private RepositoryTeam repositoryTeam;



        public TeamLogic()
        {
            repositoryTeam = new RepositoryTeam();
        }

        public Player GetOlderPlayer(Team t) => repositoryTeam.Get(t.Id).Players.OrderBy(p => p.DateOfBirth).First();
    }
}
