﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PruebaDisenoLibrary;
using PruebaDisenoPersistance;

namespace PruebaDisenoLogic
{
    public class PlayerLogic
    {
        private RepositoryPlayer repositoryPlayer;
        


        public PlayerLogic()
        {
            repositoryPlayer = new RepositoryPlayer();
        }

        public Player GetPlayerWithLessSkills() => repositoryPlayer.GetAll().OrderBy(p => p.SkillLevel).First();

    }
}
